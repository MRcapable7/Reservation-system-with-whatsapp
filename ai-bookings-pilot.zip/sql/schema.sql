-- Conversations table
CREATE TABLE IF NOT EXISTS conversations (
  id SERIAL PRIMARY KEY,
  phone TEXT NOT NULL,
  state TEXT DEFAULT 'IDLE',
  step INT DEFAULT 0,
  party_size INT,
  created_at TIMESTAMP DEFAULT NOW()
);
