# AI Bookings Pilot

## Setup
1. Run Postgres (`docker compose up -d`).
2. Apply schema: `psql bookings < sql/schema.sql`
3. Copy `.env.example` to `.env` and fill details.
4. Start server: `npm install && npm run dev`
5. Start cron reminders: `node cron.js`

## Flows
- BOOK → asks party size, date/time, checks deposit rules.
- CHANGE → asks for new time, updates booking.
- CANCEL → asks confirmation, cancels booking.

## Deposits
- Payfast link generated if party ≥6 or Fri/Sat 18-20h.

## Reminders
- Cron sends WhatsApp reminders 24h and 3h before bookings.
