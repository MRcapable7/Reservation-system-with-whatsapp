const cron = require('node-cron');
const db = require('./db');
const { sendTemplate } = require('./whatsapp');

cron.schedule('*/15 * * * *', async () => {
  let reminders = await db.getReminders();
  for (let r of reminders) {
    if (r.hours_before === 24) {
      await sendTemplate(r.phone, 'REMINDER_24H', [r.party_size, r.start_time.toString()]);
    } else if (r.hours_before === 3) {
      await sendTemplate(r.phone, 'REMINDER_3H', [r.party_size, r.start_time.toString()]);
    }
  }
});
