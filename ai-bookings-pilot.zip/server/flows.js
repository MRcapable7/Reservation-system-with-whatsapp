const db = require('./db');
const { sendWhatsAppMessage, sendTemplate } = require('./whatsapp');
const { createPayfastLink } = require('./payfast');

// Simple stateful flow manager
async function handleIncoming(userPhone, text) {
  let lower = text.trim().toLowerCase();
  let convo = await db.getConversation(userPhone);
  if (!convo) {
    convo = await db.startConversation(userPhone);
  }

  if (lower === 'book' || convo.state === 'BOOKING') {
    return await handleBooking(convo, text);
  } else if (lower === 'change' || convo.state === 'CHANGING') {
    return await handleChange(convo, text);
  } else if (lower === 'cancel' || convo.state === 'CANCELLING') {
    return await handleCancel(convo, text);
  } else {
    await sendWhatsAppMessage(userPhone, 'Hi! Reply BOOK, CHANGE, or CANCEL.');
  }
}

async function handleBooking(convo, text) {
  if (convo.step === 0) {
    await db.updateConversation(convo.id, { state: 'BOOKING', step: 1 });
    return sendWhatsAppMessage(convo.phone, 'Great! How many people?');
  } else if (convo.step === 1) {
    let partySize = parseInt(text);
    await db.updateConversation(convo.id, { step: 2, party_size: partySize });
    return sendWhatsAppMessage(convo.phone, 'Which date & time? (e.g., 2025-08-30 19:00)');
  } else if (convo.step === 2) {
    let dt = new Date(text);
    await db.createBooking(convo.phone, convo.party_size, dt);
    // Check deposit rules
    let requiresDeposit = convo.party_size >= 6 || [5,6].includes(dt.getDay()) && dt.getHours()>=18 && dt.getHours()<=20;
    if (requiresDeposit) {
      let link = createPayfastLink(convo.phone, 200); // R200 deposit stub
      return sendWhatsAppMessage(convo.phone, `Please pay deposit to confirm: ${link}`);
    } else {
      await sendTemplate(convo.phone, 'CONFIRM_BOOKING', [convo.party_size, dt.toString()]);
      return;
    }
  }
}

async function handleChange(convo, text) {
  if (convo.step === 0) {
    await db.updateConversation(convo.id, { state: 'CHANGING', step: 1 });
    return sendWhatsAppMessage(convo.phone, 'Please provide new date & time.');
  } else if (convo.step === 1) {
    let dt = new Date(text);
    await db.updateBookingTime(convo.phone, dt);
    await sendTemplate(convo.phone, 'CHANGE_OK', [dt.toString()]);
  }
}

async function handleCancel(convo, text) {
  if (convo.step === 0) {
    await db.updateConversation(convo.id, { state: 'CANCELLING', step: 1 });
    return sendWhatsAppMessage(convo.phone, 'Confirm cancel? Reply YES to confirm.');
  } else if (convo.step === 1 && text.trim().toLowerCase() === 'yes') {
    await db.cancelBooking(convo.phone);
    await sendTemplate(convo.phone, 'CANCEL_OK', []);
  }
}

module.exports = { handleIncoming };
