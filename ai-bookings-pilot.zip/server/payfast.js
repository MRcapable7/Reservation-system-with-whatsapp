function createPayfastLink(customerPhone, amount) {
  // Stub: in production call Payfast API to create payment link
  return `https://sandbox.payfast.co.za/eng/process?amount=${amount}&phone=${customerPhone}`;
}

module.exports = { createPayfastLink };
